import React from 'react';

import Home from './Pages/Home/Home.jsx'


function App() {
  
  return (
    <div id="WebPage">
      <Home />
    </div>
  )
}



export default App;