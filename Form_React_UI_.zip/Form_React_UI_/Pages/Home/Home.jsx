import React from 'react';

import Fields from '../../Components/Form/form.jsx'

function Home() {
  return (
    <div id="container">
       <Fields />
    </div>
  )
}

export default Home;